
var appConfig = {
    'iddsAPI_request': "https://aipanda160.cern.ch:443/idds/monitor_request/null/null",
    'iddsAPI_transform': "https://aipanda160.cern.ch:443/idds/monitor_transform/null/null",
    'iddsAPI_processing': "https://aipanda160.cern.ch:443/idds/monitor_processing/null/null",
    'iddsAPI_transform_detail': "https://aipanda160.cern.ch:443/idds/monitor/null/null/true/false",
    'iddsAPI_processing_detail': "https://aipanda160.cern.ch:443/idds/monitor/null/null/false/true"
}
